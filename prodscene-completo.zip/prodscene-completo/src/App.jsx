export default function App() {
  return (
    <div style={{ padding: 40, fontFamily: 'sans-serif', textAlign: 'center' }}>
      <h1>Prodscene está no ar! 🎬</h1>
      <p>Seu MVP foi publicado com sucesso via Vercel + GitHub.</p>
    </div>
  );
}
